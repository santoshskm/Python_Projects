from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime
# Create your views here.

def live_status(request):
    date = datetime.now()
    import random
    run=random.randint(1,7)
    over=random.randint(1,50)
    wicket=random.randint(1,12)
    score_board={'runs':run,'overs':over,'wickets':wicket,'date':date}
    return render(request,'cric_app/score_page.html',score_board)
