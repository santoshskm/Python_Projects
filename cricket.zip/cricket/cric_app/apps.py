from django.apps import AppConfig


class CricAppConfig(AppConfig):
    name = 'cric_app'
